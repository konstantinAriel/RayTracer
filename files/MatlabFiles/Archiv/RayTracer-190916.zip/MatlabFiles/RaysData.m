function [Ray, Normal, RefRay]  = RaysData (M, O, Ray0, D)

L =1000;

x0 = Ray0.dS(1,1);
y0 = Ray0.dS(1,2);
z0 = Ray0.dS(1,3);

kX = Ray0.K(1,1);
kY = Ray0.K(1,2);
kZ = Ray0.K(1,3);

% absK = sqrt(Ray0.K*Ray0.K');
% kX = Ray0.K(1,1)/absK;
% kY = Ray0.K(1,2)/absK;
% kZ = Ray0.K(1,3)/absK;
% absK1 = sqrt(kX^2+kY^2+kZ^2)

dx = M.f.X;
dy = M.f.Y;
dz = M.f.Z;

Cx =  M.C.Cx;
Cz =  M.C.Cz;
Cy =  M.C.Cy;

Cxz = M.C.Cxz;
Cxx = M.C.Cxx;
Czz = M.C.Czz;

%% 1

%aMir = (Cxx*kX^2 + 2*Cxz*kX*kZ + Czz*kZ^2);
%bMir = 2*Cxx*kX*x0 + Cz*kZ - Cy*kY - Cx*kX + 2*Cxz*kZ*x0 + 2*Cxz*kX*z0 + 2*Czz*kZ*z0;
%cMir = Cy*dy - Cy*y0 + Cx*x0 + Cz*z0 + Cxx*x0^2 + Czz*z0^2 + 2*Cxz*x0*z0;

 A = (Cxx*kX^2 + 2*Cxz*kX*kZ + Czz*kZ^2);
 B = 2*Cxx*kX*(x0-dx) + Cz*kZ - Cy*kY + Cx*kX + 2*Cxz*kZ*(x0-dx) + 2*Cxz*kX*(z0-dz) + 2*Czz*kZ*(z0-dz);
 C = -Cy*(y0-dy) + Cx*(x0-dx) + Cz*(z0-dz) + Cxx*(x0-dx)^2 + Czz*(z0-dz)^2 + 2*Cxz*(x0-dx)*(z0-dz);
 
%CoeffMir = [ - Cxx*kX^2 - Czz*(cos(a_Rad)*kZ + kY*sin(a_Rad))^2 - 2*Cxz*kX*(cos(a_Rad)*kZ + kY*sin(a_Rad)),... 
%				2*Cxy*(dx - x0)*(cos(a_Rad)*kY + kZ*sin(a_Rad)) - Cy*(cos(a_Rad)*kY + kZ*sin(a_Rad)) - Cz*(cos(a_Rad)*kZ - kY*sin(a_Rad)) - Cx*kX - 2*Cyy*(cos(a_Rad)*kY + kZ*sin(a_Rad))*(cos(a_Rad)*y0 - dy + sin(a_Rad)*z0) + 2*Cxx*kX*(dx - x0) - 2*Cxy*kX*(cos(a_Rad)*y0 - dy + sin(a_Rad)*z0),...
%				Cx*(dx - x0) - Cy*(cos(a_Rad)*y0 - dy + sin(a_Rad)*z0) - Cxx*(dx - x0)^2 - Cyy*(cos(a_Rad)*y0 - dy + sin(a_Rad)*z0)^2 + Cz*(dz - cos(a_Rad)*z0 + sin(a_Rad)*y0) + 2*Cxy*(dx - x0)*(cos(a_Rad)*y0 - dy + sin(a_Rad)*z0)];
 
p = [A B C];     % aMir*x^2 + bMir*x  + cMir = 0
t = roots(p);                       
[tX, ~] = size(t);

 p1 = (-B+sqrt((B^2)-(4*A*C)))/(2*A);
 p2 = (-B-sqrt((B^2)-(4*A*C)))/(2*A);
 p = [p1 p2];
t1 = p>0;
t1 = find(t1);
minP = min(abs(p));
if tX == 1
%x1 = x0 + D*kX*t(1,1);
%y1 = y0 + D*kY*t(1,1)Czz
%z1 = z0 + D*kZ*t(1,1)
x1 = x0 + kX*t(1,1);
y1 = y0 + kY*t(1,1);
z1 = z0 + kZ*t(1,1);
elseif tX == 2
x1 = x0 + kX*p(t1);
y1 = y0 + kY*p(t1);
z1 = z0 + kZ*p(t1);

x2 = x0 + kX*p(t1);
y2 = y0 + kY*p(t1);
z2 = z0 + kZ*p(t1);
b = Czz*(z2 - dz)^2;
d = - Cy*(y2 - dy);
a= b+d;
if a > 0.0001 || a < (-0.001)
disp('Error')
end
end
%chekMirror =  ((Cxx*(x1 - dx)^2 + 2*Cxz*(x1 - dx)*(z1 - dz) + Czz*(z1 - dz)^2 + Cx*(x1 - dx) + Cz*(z1 - dz))) - Cy*(y1 - dy)

Ray = struct ('X0', x0, 'Y0', y0,'Z0', z0,...
             'X', x1, 'Y', y1, 'Z', z1,...
             'kX', kX, 'kY', kY, 'kZ', kZ);
%%  Normal
Nx = (2*Cxx*(x1-dx) + 2*Cxz*(z1-dz) + Cx);
Nz = (2*Czz*(z1-dz) + 2*Cxz*(x1-dx) + Cz);
Ny = -Cy;

absNormal =sqrt( [Nx Ny Nz] * [Nx Ny Nz]');
Nx = Nx/absNormal;
Ny = Ny/absNormal;
Nz = Nz/absNormal;

%Nx =  (2*Cxx*(x1-dx) + 2*Cxy*x1*(cos(a_Rad) + sin(a_Rad) - dy) + Cx*x1);
%Ny =  (2*Cxy*(x1-dx)*cos(a_Rad) + 2*Cyy*(cos(a_Rad)*y1+sin(a_Rad)*z1-dy)*cos(a_Rad) + Cy*cos(a_Rad) - Cz*sin(a_Rad));
%Nz =  -(2*Cxy*(x1-dx)*sin(a_Rad) + 2*Cyy*(cos(a_Rad)*y1 + sin(a_Rad)*z1 - dy)*sin(a_Rad) + Cy*sin(a_Rad) - Cz*cos(a_Rad));

%xN =  x1 - 100;
%yN = (Ny/Nx)*(xN - x1) + y1;
%zN = (Nz/Nx)*(xN - x1) + z1;

xN = x1 - D*Nx*L;
yN = y1 - D*Ny*L;
zN = z1 - D*Nz*L;

Normal   = struct('X0', x1, 'Y0', y1, 'Z0', z1,...
                  'X',xN,  'Y', yN,  'Z', zN,...
		 	         'kX', Nx,  'kY', Ny,  'kZ', Nz);
%%  Reflected
n = [Nx  Ny  Nz];
k = [kX kY kZ];
c1 = Rotor (n , k);
c2 = Rotor(c1, n);
  
N1  =(k*n')*n;
absN = sqrt(n*n');
kref=(c2-N1)/absN;

RefX = kref(1);
RefY = kref(2);
RefZ = kref(3);
%absRefK = sqrt(kref*kref');
%RefX = kref(1)/absRefK;
%RefY = kref(2)/absRefK;
%RefZ = kref(3)/absRefK;
%absRefK2 = sqrt(RefX^2+RefY^2+RefZ^2);

if  abs(RefY) < abs(RefZ)
zRef = -D*O;
tRef = (zRef - z1)/RefZ;
xRef = x1 + RefX*tRef;
yRef = y1 + RefY*tRef;
elseif abs(RefZ) < abs(RefY)
yRef = -D*O;
tRef = (yRef - D*y1)/RefY;
xRef = x1 + RefX*tRef;
zRef = z1 + RefZ*tRef;
end
RefRay = struct('X0', x1, 'Y0', y1, 'Z0', z1,...
					 'X',xRef, 'Y', yRef, 'Z', zRef,...
					 'kX', RefX, 'kY', RefY, 'kZ', RefZ);

end

