clear all; close all ; clc;

L1 = 1300;
L11 = 400;
L12 = L1 - L11;
dTline = 125;

dx = 0;
dy = 0;
dz = -400;

O = struct('X', dx, 'Y', dy, 'Z', dz);
 
M1 = SetMir(L11, O, 1,  dTline*2);
M2 = SetMir(L12, O, -1, dTline*2);

Ploting (M1);
Ploting (M2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
plot3 ([M1.s0.X M1.s0.X],[M1.s0.Y (M1.m0.Y + dTline)],[M1.s0.Z+dTline M1.m0.Z+dTline], '--b', 'Linewidth', 1);  %TLine
plot3 ([M1.s0.X M1.s0.X],[M1.s0.Y (M1.m0.Y - dTline)],[M1.s0.Z-dTline M1.m0.Z-dTline], '--b' ,'Linewidth', 1);  %TLine
plot3 ([M1.m0.X M1.m0.X],[(M1.m0.Y+dTline) (M1.m0.Y+dTline)],[(M1.m0.Z+dTline) (M2.m0.Z+dTline)], '--b',  'Linewidth', 1); %TLine
plot3 ([M1.m0.X M1.m0.X],[(M1.m0.Y-dTline) (M1.m0.Y-dTline)],[(M1.m0.Z-dTline) (M2.m0.Z-dTline)], '--b',  'Linewidth', 1); %TlINE
plot3 ([M2.m0.X M2.m0.X ],[(M2.m0.Y+dTline) M2.m0.Y - L12 ],[(M2.m0.Z+dTline) (M2.m0.Z+dTline)], '--b',  'Linewidth', 1)
plot3 ([M2.m0.X M2.m0.X ],[(M2.m0.Y-dTline) M2.m0.Y - L12 ],[(M2.m0.Z-dTline) (M2.m0.Z-dTline)], '--b',  'Linewidth', 1)

plot3 ([O.X M1.f.X], [O.Y M1.f.Y], [M1.s1.Z M1.f.Z], 'Linewidth', 2)   %FOCUS lINE
plot3 ([O.X M2.f.X], [O.Y M2.f.Y], [M1.s1.Z M2.f.Z], 'Linewidth', 2)   %FOCUS lINE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

K =[ 0 -1 -0.05;  0  -1  -0.02; 0 -1  -0.01;  0  -1   0;   0  -1  0.01;   0  -1  0.02;  0  -1  0.05; ];
dS =10* [0 0  -6; 0 0 -4;  0 0 -2;  0 0 0; 0  0 2; 0 0 4; 0 0 6];
[nx, ny] = size(K);
 [mx, my] = size (dS);
 
 Kmin = 1;
 Kmax =nx;
 
 dSmin =2;
 dSmax =mx-1;
 
 for i = dSmin:dSmax
     for j=Kmin:Kmax
         dSi = dS(i,: );
         Kj = K(j, :);

dSi(1,1) = M1.s0.X + dSi(1,1);
dSi(1,2) = M1.s0.Y + dSi(1,2);
dSi(1,3) = M1.s0.Z + dSi(1,3);

			RayIn  = struct('K', Kj, 'dS', dSi);
			[Ray11(i,j), Normal1, RefRay1(i,j)]  = RaysData (M1, O.Z, RayIn, 1);
			
 plot3 ([Ray11(i,j).X0, Ray11(i,j).X], [Ray11(i,j).Y0, Ray11(i,j).Y], [Ray11(i,j).Z0, Ray11(i,j).Z]);                                          %	 OutRay  from Source
% plot3 ([Normal1.X0, Normal1.X], [Normal1.Y0, Normal1.Y], [Normal1.Z0, Normal1.Z]);                        %  Normal to Mirror in cross with Ray
 plot3([RefRay1(i,j).X0, RefRay1(i,j).X],[RefRay1(i,j).Y0, RefRay1(i,j).Y],[RefRay1(i,j).Z0, RefRay1(i,j).Z]);                           %  Reflected Ray from Mirror
 
 k = 1; l=1;
 
			dSRefRayArr(k,1) = RefRay1(i,j).X;
			dSRefRayArr(k,2) = RefRay1(i,j).Y;
			dSRefRayArr(k,3) = RefRay1(i,j).Z;
			
			kRefRayArr (l,1) = RefRay1(i,j).kX;
			kRefRayArr (l,2) = RefRay1(i,j).kY;
			kRefRayArr (l,3) = RefRay1(i,j).kZ;
		
 			Ray2 = struct('K', kRefRayArr, 'dS', dSRefRayArr);
 		   [Ray22, Normal2, RefRay2]  = RaysData (M2, M2.s0.Y, Ray2, -1);
%  
 plot3 ([Ray22.X0, Ray22.X], [Ray22.Y0, Ray22.Y], [Ray22.Z0, Ray22.Z]);                                          %	OurRay  from Source
 
 %plot3 ([Normal2.X0, Normal2.X], [Normal2.Y0, Normal2.Y], [Normal2.Z0, Normal2.Z]);                        %  Normal to Mirror in cross with Ray
 
 plot3([RefRay2.X0, RefRay2.X],[RefRay2.Y0, RefRay2.Y],[RefRay2.Z0, RefRay2.Z]); 
 
  pause (0.3)
    end
 end
 
% % % %plot3 ([rRay.X0, rRay.X], [rRay.Y0, rRay.Y], [rRay.Z0, rRay.Z]);
% % % %plot3 ([N.x0, N.x1], [N.y0, N.y1], [N.z0, N.z1]);
% % % %plot3([rRefRay.x0, rRefRay.x1],[rRefRay.y0, rRefRay.y1],[rRefRay.z0, rRefRay.z1]);
% % % 
% % % 
% % % % % Rays
% % % % xlabel ('X');
% % % % ylabel('Y');
% % % % zlabel('Z');
% % % % grid on;
% % % % grid minor;
% % % 
% % % rTLine  = 125;

