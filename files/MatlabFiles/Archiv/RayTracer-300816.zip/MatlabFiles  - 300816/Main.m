clear all; close all ; clc;

%% Set Surface

L1 = 1300;
L2 = 400;
L3 = L1 - L2; 
 
[surfParam1, rotateParam1, shiftParam1, surfSizeParam1, Center1, F1_1, M1_1, Source1] = SetMir_1(L1, L2, L3);

[outMir_1, MirOrig] = BuildSurf(surfParam1, rotateParam1, shiftParam1, surfSizeParam1);

%[ output_args ] = BuildSource ( Center, F1, M1, Source );
%Focus1 = struct ('X',Center.X, 'Y',Center.Y,  'Z',Center.Z, 'X1',F1.X, 'Y1', F1.Y, 'Z1', F1.Z);
%Source = Struct ('X',Source.X, 'Y',Source.Y, 'Z',Source.Z, 'X1', M1.X, 'Y1',M1.Y, 'Z1',M1.Z);

Ploting (MirOrig, surfParam1, Center1, F1_1, M1_1, Source1);


K =[ -0 1 -0.05;  0  1  -0.02; 0  1  -0.01;  0  1   0;   0  1  0.01;   0  1  0.02;  0  1  0.05; ];
[nx, ny] =size(K);
Kmax =4;
Kmin = 4;
dS =10* [0 0  -6; 0 0 -4;  0 0 -2;  0 0 0; 0  0 2; 0 0 4; 0 0 6];
[mx, my]  = size (dS);
dSmax = mx;
dSmin=1;
for i = dSmin:dSmax
    dSi = dS(i,: );
    for j=Kmin:Kmax
        Kj = K(j, :);
[Ray, Normal, RefRay]  = RaysData (surfParam1, rotateParam1, shiftParam1, Source1, Kj,dSi);

plot3 ([Ray.X0, Ray.X], [Ray.Y0, Ray.Y], [Ray.Z0, Ray.Z]);                                                                          %OurRay  from Source
%plot3 ([Normal.X0, Normal.X], [Normal.Y0, Normal.Y], [Normal.Z0, Normal.Z]);                   % Normal to Mirror in cross with Ray
plot3([RefRay.x0, RefRay.x1],[RefRay.y0, RefRay.y1],[RefRay.z0, RefRay.z1]);                          %Reflected Ray from Mirror
pause (0.2)
    end
end
%plot3 ([rRay.X0, rRay.X], [rRay.Y0, rRay.Y], [rRay.Z0, rRay.Z]);
%plot3 ([N.x0, N.x1], [N.y0, N.y1], [N.z0, N.z1]);
%plot3([rRefRay.x0, rRefRay.x1],[rRefRay.y0, rRefRay.y1],[rRefRay.z0, rRefRay.z1]);

%end
% % Rays
% xlabel ('X');
% ylabel('Y');
% zlabel('Z');
% grid on;
% grid minor;

