function [ refRay ] = ReflectedRay ( Ray, Normal, L, F1 )

x1 = Ray.X;
y1 = Ray.Y;
z1 = Ray.Z;
kX = Ray.kX; 
kY = Ray.kY; 
kZ = Ray.kZ;
Nx = Normal.Nx; 
Ny = Normal.Ny;
Nz = Normal.Nz;

if kX == 0
    AlphaX_Rad = pi/2;
else
    AlphaX_Rad = atan(kY/kX);
end

if kZ == 0
    AlphaZ_Rad = pi/2;
else
    AlphaZ_Rad = atan(kY/kZ);
end

AlphaX_degre = Rad2Degree(AlphaX_Rad);
AlphaZ_degre = Rad2Degree(AlphaZ_Rad);

if Nx == 0
    BetaX_Rad = pi/2;
else
    BetaX_Rad = atan(Ny/Nx);
end

if Nz == 0
    BetaZ_Rad = pi/2;
else
    BetaZ_Rad = atan(Ny/Nz);
end

 BetaX_degre = Rad2Degree(BetaX_Rad);
 BetaZ_degre = Rad2Degree(BetaZ_Rad);

 GamaX_Rad = AlphaX_Rad - BetaX_Rad;
 GamaZ_Rad = AlphaZ_Rad - BetaZ_Rad;

GamaX_degre = Rad2Degree(GamaX_Rad);
GamaZ_degre = Rad2Degree(GamaZ_Rad);

 GamaX_ref_Rad = (AlphaX_Rad - 2*GamaX_Rad);
 GamaZ_ref_Rad = (AlphaZ_Rad - 2*GamaZ_Rad);

GamaX_ref_degre = Rad2Degree(GamaX_ref_Rad);
GamaZ_ref_degre = Rad2Degree(GamaZ_ref_Rad);

if GamaX_ref_Rad == pi/2;
RefX = 0
else
RefX = cos(GamaX_ref_Rad)
end

if GamaZ_ref_Rad == pi/2
RefZ = 0
else
RefZ = cos(GamaZ_ref_Rad)
end

RefY =sqrt(1 - (RefX^2 + RefZ^2));
% 
 xRef = x1 + RefX*L;
 yRef = y1 + RefY*L;
 zRef = z1 + RefZ*L;
%refRay = 0;
refRay = struct('x0', x1, 'y0', y1, 'z0', z1, 'x1',xRef, 'y1', yRef, 'z1', zRef);
end

