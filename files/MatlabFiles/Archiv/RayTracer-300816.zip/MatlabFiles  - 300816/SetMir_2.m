function [surfParam, rotateParam, shiftParam, surfSizeParam,Center, F1, M1, Source] = SetMir_1 
%% Surf [mm]
L1 = 1300;
L2 = 400;
L3 = L1 - L2; 
Fz = L2/2;
Fx = 10000000;

dx = 0;  
dy = 200;     %% dY > 0  => to Right
dz = -400;    %% dz > 0 =>  to UP

shiftParam = struct('dx', dx, 'dy', dy, 'dz', dz); 

xCenter =  dx; 
yCenter = -dy; 
zCenter = -dz;
Center = struct('X',xCenter, 'Y',yCenter, 'Z',zCenter);
xF = xCenter; yF = Fz -dy; zF = -dz;
F1 = struct('X',xF, 'Y',yF, 'Z',zF);
xM1 = dx ;
yM1 = Fz - dy;
zM1 = -2*Fz - dz;
M1 = struct ('X',xM1, 'Y',yM1, 'Z',zM1);
xS = dx; yS = (yM1+(2*Fz)); zS = (-2*Fz) + zCenter;
Source  = struct('X',xS, 'Y',yS, 'Z',zS);
 
Czz = 1/(4*Fz); % x^2
Cxx = 1/(4*Fx); % y^2

Cz = 0;       % x  
Cx = 0;       % y
Cxz = 0;      % x*y 
Cy = 1;
surfParam = struct('Fx', Fx, 'Fz', Fz,...
						'Cx', Cx, 'Cz', Cz, 'Cxz', Cxz, 'Cxx', Cxx,...
						'Czz', Czz, 'Cy', Cy);
						
%% Rotate [Degree]
a_Degre  = 0; 
a_Rad = Deg2Rad(a_Degre);
rotateDirection = 'X';
rotateParam = struct('a_Rad', a_Rad, 'rotateDirection', rotateDirection);

%% Shifting [mm];

%% SurfSize
dXdZ = 5;
diamX = 250;
diamZ = 250;

surfSizeParam = struct('diamX', diamX, 'diamZ', diamZ, 'dXdZ', dXdZ);

%inputMir = struct( 'Fx', Fx, 'Fy', Fy, 'Cz', Cz, 'dXdY', dXdY, 'L', L, 'X', X,'Y', Y);
end
