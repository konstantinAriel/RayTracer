function [outSurf, surfOrig] = BuildSurf (surfParam, rotateParam, shiftParam, surfSizeParam)

Cx = surfParam.Cx;
Cz = surfParam.Cz;
Cxz = surfParam.Cxz;
Cxx = surfParam.Cxx;
Czz = surfParam.Czz;
Cy = surfParam.Cy;
dx = shiftParam.dx;
dy = shiftParam.dy;
dz = shiftParam.dz;
a_Rad = rotateParam.a_Rad;

x = -surfSizeParam.diamX/2 : surfSizeParam.dXdZ : surfSizeParam.diamX/2;
z = -245 - dz  : -surfSizeParam.dXdZ : -525 - dz ;

[X ,Z] = meshgrid (x, z); 

Y =  ((Cxx*(X+dx).^2 + 2*Cxz*(X+dx).*(Z+dz) + Czz*(Z+dz).^2 + Cx.*(X+dx) + Cz.*(Z+dz)))/Cy - Cy*dy;

%Y = ((Cxx*X.^2 + 2*Cxz*X.*Z + Czz*Z.^2 + Cx.*X + Cz.*Z)/Cy);
surfOrig = struct('X', X, 'Y', Y, 'Z', Z);
outSurf = struct('X', X, 'Y', Y, 'Z', Z);

%% Rotate Mirror
%rotatedMirror = RotateMir (rotateParam,surfOrig);

%% Shift Mirror
%shiftingMir = ShiftMir (dx, dy, dz, rotatedMirror);
%outSurf = struct ('X', rotatedMirror.X, 'Y', rotatedMirror.Y, 'Z', rotatedMirror.Z);
%outSurf = struct ('X', shiftingMir.X,   'Y', shiftingMir.Y,   'Z', shiftingMir.Z);
end




