function [outSurf, surfOrig, x, y] = BuildSurfShifting (surfParam, rotateParam, shiftParam, surfSizeParam)

Cx = surfParam.Cx;
Cy = surfParam.Cy;
Cxy = surfParam.Cxy;
Cxx = surfParam.Cxx;
Cyy = surfParam.Cyy;
Cz = surfParam.Cz;
dx = shiftParam.dx;
dy = shiftParam.dy;
dz = shiftParam.dz;
a_Rad = rotateParam.a_Rad;

%% Build Original Mirror
if cos(rotateParam.a_Rad) >= 0
%x = (-surfSizeParam.diamX/(2*cos(rotateParam.a_Rad))) + dx : surfSizeParam.dXdY : (surfSizeParam.diamX/(2*cos(rotateParam.a_Rad))) + dx;
x = (-surfSizeParam.diamX/2) + dx : surfSizeParam.dXdY : (surfSizeParam.diamX/2) + dx;
y = (-surfSizeParam.diamY/(2*cos(a_Rad))) + dy : surfSizeParam.dXdY : (surfSizeParam.diamY/(2*cos(a_Rad))) + dy;


%x = -1000 : 5 : 1000;
%y = -1000 : 5 : 1000;
else
x = (-surfSizeParam.diamX/(2*cos(rotateParam.a_Rad))) + dx : -surfSizeParam.dXdY : (surfSizeParam.diamX/(2*cos(rotateParam.a_Rad))) + dx;
y = (-surfSizeParam.diamY/(2*cos(rotateParam.a_Rad))) + dy : -surfSizeParam.dXdY : (surfSizeParam.diamY/(2*cos(rotateParam.a_Rad))) + dy; 
end



[X ,Y] = meshgrid (x, y); 

Z = - ((Cxx*(X-dx).^2 + 2*Cxy*(X-dx).*(Y-dy) + Cyy*(Y-dy).^2 + Cx.*(X-dx) + Cy.*(Y-dy)))/Cz + dz;
%Z = -((Cxx*X.^2 + 2*Cxy*X.*Y + Cyy*Y.^2 + Cx.*X + Cy.*Y)/Cz);
surfOrig = struct('X', X, 'Y', Y, 'Z', Z);

%% Rotate Mirror
 
rotatedMirror = RotateMir (rotateParam,surfOrig);

%% Shid=ft Mirror
%shiftingMir = ShiftMir (dx, dy, dz, rotatedMirror);

outSurf = struct ('X', rotatedMirror.X, 'Y', rotatedMirror.Y, 'Z', rotatedMirror.Z);
%outSurf = struct ('X', X, 'Y', Y, 'Z', Z);

%outSurf = struct ('X', shiftingMir.X,   'Y', shiftingMir.Y,   'Z', shiftingMir.Z);

end


