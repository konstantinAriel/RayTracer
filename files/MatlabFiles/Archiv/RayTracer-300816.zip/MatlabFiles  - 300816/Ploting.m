function Ploting (surfOrig, surfParam1, Center, F1, M1, Source,p)
%%Original Mirrror1
rTLine  = 125;
figure(1);
plot3 ([Source.X M1.X],[Source.Y M1.Y+rTLine],[Source.Z+rTLine M1.Z+rTLine]);
hold on;
plot3 ([Source.X M1.X],[Source.Y M1.Y-rTLine],[Source.Z-rTLine M1.Z-rTLine]);

plot3 ([M1.X  M1.X],[M1.Y+rTLine M1.Y+rTLine],[M1.Z+rTLine M1.Z+rTLine+(surfParam1.Fz*4)]); 
plot3 ([M1.X  M1.X],[M1.Y-rTLine M1.Y-rTLine],[M1.Z-rTLine M1.Z-rTLine+(surfParam1.Fz*4)]); 

mesh( surfOrig.X, surfOrig.Y, surfOrig.Z );  % Mirror 1
plot3 ([Center.X F1.X], [Center.Y F1.Y], [Center.Z F1.Z], 'Linewidth', 2)
plot3 ([Source.X M1.X], [Source.Y (M1.Y+(surfParam1.Fz*2)/3)], [Source.Z M1.Z], 'Linewidth', 2);

grid on;
xlabel('X');
ylabel('Y');
zlabel('Z');
axis 'equal';
view(90,0);
set(gcf, 'renderer', 'opengl')

%% Rotated Mirror
%figure (2)
%mesh( outMir_1.X, outMir_1.Y, outMir_1.Z );
%hold on;
%view(90,0);
%axis 'equal';
end

