function [Ray, Normal, RefRay]  = RaysData (surfParam, rotateParam, shiftParam, Source, K, dS )

x0 = Source.X + dS(1,1);
y0 = Source.Y + dS(1,2);
z0 = Source.Z + dS(1,3);

L =1000;

kX = K(1,1); 
kY = K(1,2);
kZ = K(1, 3);

Cx = surfParam.Cx;
Cz = surfParam.Cz;
Cxz = surfParam.Cxz;
Cxx = surfParam.Cxx;
Czz = surfParam.Czz;
Cy = surfParam.Cy;
dx = shiftParam.dx;
dy = shiftParam.dy;
dz = shiftParam.dz;
a_Rad = rotateParam.a_Rad;

%%  Cross with Mirror
	%aMir = (Cxx*kX^2 + 2*Cxz*kX*kZ + Czz*kZ^2);
	%bMir = 2*Cxx*kX*x0 + Cz*kZ - Cy*kY - Cx*kX + 2*Cxz*kZ*x0 + 2*Cxz*kX*z0 + 2*Czz*kZ*z0;
	%cMir = Cy*dy - Cy*y0 + Cx*x0 + Cz*z0 + Cxx*x0^2 + Czz*z0^2 + 2*Cxz*x0*z0;
 
 aMir = (Cxx*kX^2 + 2*Cxz*kX*kZ + Czz*kZ^2);
 bMir = 2*Cxx*kX*(x0+dx) + Cz*kZ - Cy*kY - Cx*kX + 2*Cxz*kZ*(x0+dx) + 2*Cxz*kX*(z0+dz) + 2*Czz*kZ*(z0+dz);
 cMir = -Cy*(y0+dy) + Cx*(x0+dx) + Cz*(z0+dz) + Cxx*(x0+dx)^2 + Czz*(z0+dz)^2 + 2*Cxz*(x0+dx)*(z0+dz);
 
%CoeffMir = [ - Cxx*kX^2 - Czz*(cos(a_Rad)*kZ + kY*sin(a_Rad))^2 - 2*Cxz*kX*(cos(a_Rad)*kZ + kY*sin(a_Rad)),... 
%					2*Cxy*(dx - x0)*(cos(a_Rad)*kY + kZ*sin(a_Rad)) - Cy*(cos(a_Rad)*kY + kZ*sin(a_Rad)) - Cz*(cos(a_Rad)*kZ - kY*sin(a_Rad)) - Cx*kX - 2*Cyy*(cos(a_Rad)*kY + kZ*sin(a_Rad))*(cos(a_Rad)*y0 - dy + sin(a_Rad)*z0) + 2*Cxx*kX*(dx - x0) - 2*Cxy*kX*(cos(a_Rad)*y0 - dy + sin(a_Rad)*z0),...
%					Cx*(dx - x0) - Cy*(cos(a_Rad)*y0 - dy + sin(a_Rad)*z0) - Cxx*(dx - x0)^2 - Cyy*(cos(a_Rad)*y0 - dy + sin(a_Rad)*z0)^2 + Cz*(dz - cos(a_Rad)*z0 + sin(a_Rad)*y0) + 2*Cxy*(dx - x0)*(cos(a_Rad)*y0 - dy + sin(a_Rad)*z0)];
 
p = [aMir bMir cMir];     % aMir*x^2 + bMir*x  + cMir = 0
t = roots(p)  ;                           
[tX, ~] = size(t);
if tX == 1
% t1 = (-B+sqrt(B^2-4*A*C))/(2*A);
% t2 = -B-(B^2-4*A*C); 
x1 = x0+ kX*t(1,1);
y1 = y0 +kY*t(1,1);
z1 = z0+kZ*t(1,1);
elseif tX == 2
x1 = x0 + kX*t(2,1);
y1 = y0 + kY*t(2,1);
z1 = z0 + kZ*t(2,1);
end

Ray = struct ('X0', x0, 'Y0', y0,'Z0', z0,...
             'X', x1, 'Y', y1, 'Z', z1,...
             'kX', kX, 'kY', kY, 'kZ', kZ);  
%%
Nx = (2*Cxx*(x1+dx) + 2*Cxz*(z1+dz) + Cx);
Nz = (2*Czz*(z1+dz) + 2*Cxz*(x1+dx) + Cz);
Ny = -Cy;
%Nx =  (2*Cxx*(x1-dx) + 2*Cxy*x1*(cos(a_Rad) + sin(a_Rad) - dy) + Cx*x1);
%Ny =  (2*Cxy*(x1-dx)*cos(a_Rad) + 2*Cyy*(cos(a_Rad)*y1+sin(a_Rad)*z1-dy)*cos(a_Rad) + Cy*cos(a_Rad) - Cz*sin(a_Rad));
%Nz =  -(2*Cxy*(x1-dx)*sin(a_Rad) + 2*Cyy*(cos(a_Rad)*y1 + sin(a_Rad)*z1 - dy)*sin(a_Rad) + Cy*sin(a_Rad) - Cz*cos(a_Rad));

%xN =  x1 - 100;
%yN = (Ny/Nx)*(xN - x1) + y1;
%zN = (Nz/Nx)*(xN - x1) + z1;

xN = x1 - Nx*L;
yN = y1 - Ny*L;
zN = z1 - Nz*L;

Normal   = struct('X0', x1, 'Y0', y1, 'Z0', z1,...
                  'X',xN,  'Y', yN,  'Z', zN,...
		 	         'Nx', Nx,  'Ny', Ny,  'Nz', Nz);
	
  n = [Nx  Ny  Nz];
  k = [kX kY kZ];
  c1 =  Rotor (n , k);
  c2 = Rotor(n, c1);
  
 N1  =(k*n')*n;
 absN = n*n' ;
       kref=(c2+N1)/absN;
RefX = kref(1);
RefY =  kref(2);
RefZ = kref(3);

 zRef = -dz*3;
 t1 = (zRef - z1)/RefZ;
 xRef = x1 + RefX*t1;
 yRef = y1 + RefY*t1;

RefRay = struct('x0', x1, 'y0', y1, 'z0', z1, 'x1',xRef, 'y1', yRef, 'z1', zRef);
%RefRay = ReflectedRay (Ray, Normal, L, F1);
%rNormal = RotateMir (rotateParam, Normal);
%rRefRay = RotateMir (rotateParam, RefRay);
end

