function   a_Rad = Deg2Rad(a_Deg )
   a_Rad = a_Deg*pi/180;
end

