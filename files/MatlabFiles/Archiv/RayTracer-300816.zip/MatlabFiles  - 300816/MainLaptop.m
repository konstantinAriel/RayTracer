clear all; close all ; clc;

%% Set Surface 
Surf_0 = SetSurf_0;
[surfParam, rotateParam, shiftParam, surfSizeParam] = SetMir_1;

%% BuildSurf
%outSurf_0 = BuildSurf (Surf_0);
[outMir_1, x, y] = BuildSurf(surfParam, rotateParam, shiftParam, surfSizeParam);

Ploting (outMir_1);

[Ray] = RaysData( surfParam, rotateParam, shiftParam );

[ T, RayOut, coefT ] = SymSolver(surfParam, rotateParam, shiftParam, surfSizeParam, Ray);
%plot3(Ray)
plot3 ([RayOut.x0, RayOut.x], [RayOut.y0, RayOut.y], [RayOut.z0, RayOut.z]);
%plot3 ([Ray1.x0, Ray1.X], [Ray1.y0, Ray1.Y], [Ray1.z0, Ray1.Z]);
% % Rays
% 
%
% 
% xlabel ('X');
% ylabel('Y');
% zlabel('Z');
% grid on;
% grid minor;

