function Ploting (M1)
%%Original Mirrror1

figure (1);
mesh( M1.X, M1.Y, M1.Z );  % Mirror 1
hold on;
grid on;
xlabel('X');
ylabel('Y');
zlabel('Z');
axis 'equal';
view(90,0);
colormap([0 0 0]);
set(gcf, 'renderer', 'opengl')
%  annotation('textbox',[0.55725 0.392116182572614 0.0109791666666667 0.0238589211618257],'String',{'F'},'FitBoxToText','off');
%  % Create textbox
%     annotation('textbox',[0.6838125 0.133817427385892 0.0125416666666667 0.0269709543568465],'String',{'S'},'FitBoxToText','on');
%     
%     % Create ellipse
%     annotation('ellipse',[0.678645833333333 0.163900414937759 0.00989583333333333 0.024896265560166],'Color',[1 0 0],'FaceColor',[1 0 0]);
%     
%     % Create ellipse
%     annotation('ellipse',[0.329125 0.845435684647303 0.00941666666666668 0.0269709543568464],'FaceColor',[1 0 0]);
%     
%     % Create textbox
%     annotation('textbox',[0.3234375 0.873481328357305 0.0161458333333334 0.0290456425970521],'String',{'R'},'FitBoxToText','off');
%% Rotated Mirror
%figure (2)
%mesh( outMir_1.X, outMir_1.Y, outMir_1.Z );
%hold on;
%view(90,0);
%axis 'equal';
end

