function M = SetMir (L11, O, D, dTline)
%% Surf [mm]

Fz = L11/2;
Fx = 10000000;

%% Shift
dx = O.X; dy = O.Y; dz = O.Z;
 
%% Focus
xF = -dx
yF = -D*(L11/2) - dy
zF = -dz
f = struct('X',xF, 'Y',yF, 'Z',zF);

%% Center
xM= -dx; yM = -dy; zM = -D*L11 - dz;
m0 = struct ('X',xM, 'Y',yM, 'Z',zM);

%% Source 0
xS0 = -dx; yS0 = D*L11 - dy ; zS0 = -D*L11 - dz;
s0  = struct('X',xS0, 'Y',yS0, 'Z',zS0);

%% Source 1
xS1 = -dx; yS1 = -dy; zS1 = -dz; 
s1 = struct('X',xS1, 'Y',yS1, 'Z',zS1);

Czz = 1/(4*Fz)*D;       					 %		 x^2
Cxx = 1/(4*Fx)*D;               	    %          Z^2
Cyy = 0;                      	    	 %		 y^1
Cx = 0;                               %		 x
Cz = 0;                               %		 z  
Cy = 1;                               %		 y
Cxz = 0;                              %	 	x*y 

surfParam = struct('Fx', Fx, 'Fz', Fz,...
						'Cx', Cx, 'Cz', Cz, 'Cxz', Cxz, 'Cxx', Cxx,...
						'Czz', Czz, 'Cy', Cy);
%% Build Mirror				
dxdy = 5;	
x = -dTline/2 : dxdy*5 : dTline/2;
z = m0.Z - dTline/2  : dxdy*5 : m0.Z + dTline/2 ;
%z = -250  : dxdy : 1400;
[X ,Z] = meshgrid (x, z); 
Y =  ((Cxx*(X - f.X).^2 + 2*Cxz*(X - f.X).*(Z - f.Z) + Czz*(Z - f.Z).^2 + Cx.*(X - f.X) + Cz.*(Z - f.Z)))/Cy + Cy*f.Y;
			
M = struct ('C', surfParam, 'f', f, 'm0', m0, 's0', s0, 's1', s1, 'X', X, 'Y', Y, 'Z', Z );

%%  Rotate [Degree]
a_Degre  = 0; 
a_Rad = Deg2Rad(a_Degre);
rotateDirection = 'X';
rotateParam = struct('a_Rad', a_Rad, 'rotateDirection', rotateDirection);

end
