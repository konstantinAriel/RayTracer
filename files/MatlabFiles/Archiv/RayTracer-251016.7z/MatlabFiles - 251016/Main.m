clear all; close all ; clc;

L1 = 1300;
L11 = 400;
L12 = L1 - L11;
L2 = 4000;
rTline = 125;

dx = 0;
dy = 0;
dz = -400;

O = struct('X', dx, 'Y', dy, 'Z', dz);
 
M1 = SetMir(L11, O, 1,  rTline*2);
M2 = SetMir(L12, O, -1, rTline*2);

Ploting (M1);
Ploting (M2);

LW = 2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
plot3 ([M1.s0.X M1.s0.X], [M1.s0.Y (M1.m0.Y + rTline)], [M1.s0.Z+rTline M1.m0.Z+rTline], '--b', 'Linewidth', LW);                                  %TLine - S-M1
plot3 ([M1.s0.X M1.s0.X],[ M1.s0.Y (M1.m0.Y - rTline)], [M1.s0.Z-rTline M1.m0.Z-rTline], '--b' ,'Linewidth', LW);                                     %TLine - S-M1

plot3 ([M1.m0.X M1.m0.X], [(M1.m0.Y+rTline) (M1.m0.Y+rTline)], [(M1.m0.Z+rTline) (M2.m0.Z+rTline)], '--b', 'Linewidth', LW);        %TLine - M1-M2
plot3 ([M1.m0.X M1.m0.X], [(M1.m0.Y-rTline) (M1.m0.Y-rTline)], [(M1.m0.Z-rTline) (M2.m0.Z-rTline)], '--b',  'Linewidth', LW);           %TlINE - M1-M2

plot3 ([M2.m0.X M2.m0.X ], [(M2.m0.Y+rTline) M2.m0.Y - L2 ], [(M2.m0.Z+rTline) (M2.m0.Z+rTline)], '--b',  'Linewidth', LW);             %TLine - M2-M3
plot3 ([M2.m0.X M2.m0.X ], [(M2.m0.Y-rTline) M2.m0.Y - L2 ], [(M2.m0.Z-rTline) (M2.m0.Z-rTline)], '--b',  'Linewidth', LW)                 %Tline -M2-M3

plot3 ([0  -3800-rTline ], [(M2.m0.Y - L2) M2.m0.Y - L2 ], [(M2.m0.Z+rTline) (M2.m0.Z+rTline)], '--b',  'Linewidth', LW);                           %TLine - M3-M4
plot3 ([0 -3800+rTline ], [(M2.m0.Y - L2) M2.m0.Y - L2], [(M2.m0.Z-rTline) (M2.m0.Z-rTline)], '--b',  'Linewidth', LW)                              %Tline -M3-M4

plot3 ([ -3800-rTline   -3800-rTline ],  [(M2.m0.Y - L2) M2.m0.Y - L2 ], [(M2.m0.Z+rTline) (M2.m0.Z-700)], '--b',  'Linewidth', LW);             %TLine - M3-M4
plot3 ([-3800+rTline -3800+rTline ],  [(M2.m0.Y - L2) M2.m0.Y - L2 ], [(M2.m0.Z-rTline) (M2.m0.Z-700)], '--b',  'Linewidth', LW)                 %Tline -M3-M4

plot3 ([O.X M1.f.X], [O.Y M1.f.Y], [M1.s1.Z M1.f.Z], 'Linewidth', 2)   %FOCUS  LINE M1
plot3 ([O.X M2.f.X], [O.Y M2.f.Y], [M1.s1.Z M2.f.Z], 'Linewidth', 2)   %FOCUS  LINE M2

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

AmplE = 100;

K =[ 0 -1 -0.07;  0  -1  -0.02; 0 -1  -0.01;  0  -1   0;   0  -1  0.01;   0  -1  0.02;  0  -1  0.05; ];
%K =[ -0.05 -1 -0.05;  -0.02  -1  -0.02; 0.01 -1  -0.01;  0  -1   0;   0.01  -1  0.01;   0.02  -1  0.02;  0.05  -1  0.05; ];
%K =[ -0.05 -1 0;  -0.02  -1  0; -0.01 -1  0;  0  -1   0;   0.01  -1  0;   0.02  -1  0;  0.05  -1  0;];
dS = [0 0  -5; 0 0 -4;  0 0 -2;  0 0 0; 0  0 2; 0 0 4; 0 0 5];
%dS =10* [-6 0  0; -4 0 0;  -2 0 0;  0 0 0; 2  0 0; 4 0 0; 6 0 0];
[nx, ny] = size(K);
[mx, my] = size (dS);
 
 Kmin = 4;
 Kmax = 4;
 
 dSmin = 4;
 dSmax =4;
 
 for i = dSmin:dSmax
     for j=Kmin:Kmax
         dSi = dS(i,: );
         Kj = K(j, :);

dSi(1,1) = M1.s0.X + dSi(1,1);
dSi(1,2) = M1.s0.Y + dSi(1,2);
dSi(1,3) = M1.s0.Z + dSi(1,3);

			RayIn  = struct('K', Kj, 'dS', dSi);
			[Ray11(i,j), Normal1(i,j), RefRay1(i,j)]  = RaysData (M1, O.Z, RayIn, 1);
			
			[ePolarRay, rPolarRay] = PolarVector (Ray11(i,j), Normal1(i,j), AmplE);
			
 	plot3([Ray11(i,j).X0, Ray11(i,j).X], [Ray11(i,j).Y0, Ray11(i,j).Y], [Ray11(i,j).Z0, Ray11(i,j).Z]);                                      %  OutRay  from Source
	plot3([RefRay1(i,j).X0, RefRay1(i,j).X],[RefRay1(i,j).Y0, RefRay1(i,j).Y],[RefRay1(i,j).Z0, RefRay1(i,j).Z]);                %  Reflected Ray from Mirror
	%plot3([RefRay1(i,j).X0, RefRay1(i,j).X],[RefRay1(i,j).Y0, RefRay1(i,j).Y],[RefRay1(i,j).Z0, RefRay1(i,j).Z]);                %  Reflected Ray from Mirror
   %plot3 ([Normal1.X0, Normal1.X], [Normal1.Y0, Normal1.Y], [Normal1.Z0, Normal1.Z]);                                                   %  Normal to Mirror in cross with Ray
 	%plot3([ePolarRay.X0, ePolarRay.X],[ePolarRay.Y0, ePolarRay.Y],[ePolarRay.Z0, ePolarRay.Z], 'r', 'Linewidth', 2);  
 	%plot3([rPolarRay.X0, rPolarRay.X],[rPolarRay.Y0, rPolarRay.Y],[rPolarRay.Z0, rPolarRay.Z], 'r', 'Linewidth', 2);  
 k = 1; l=1;
 
			dSRefRayArr(k,1) = RefRay1(i,j).X;
			dSRefRayArr(k,2) = RefRay1(i,j).Y;
			dSRefRayArr(k,3) = RefRay1(i,j).Z;
			
			kRefRayArr (l,1) = RefRay1(i,j).kX;
			kRefRayArr (l,2) = RefRay1(i,j).kY;
			kRefRayArr (l,3) = RefRay1(i,j).kZ;
		
 			Ray2 = struct('K', kRefRayArr, 'dS', dSRefRayArr);
 		   [Ray22(i,j), Normal2(i,j), RefRay2(i,j)]  = RaysData (M2, M2.s0.Y, Ray2, -1);
		   
  plot3([RefRay2(i,j).X0, RefRay2(i,j).X],[RefRay2(i,j).Y0, RefRay2(i,j).Y],[RefRay2(i,j).Z0, RefRay2(i,j).Z]); 
  plot3 ([Ray22(i,j).X0, Ray22(i,j).X], [Ray22(i,j).Y0, Ray22(i,j).Y], [Ray22(i,j).Z0, Ray22(i,j).Z]);                                          %	OutRay  from Source
%  plot3 ([Normal2.X0, Normal2.X], [Normal2.Y0, Normal2.Y], [Normal2.Z0, Normal2.Z]);                                                     %  Normal to Mirror in cross with Ray
 Test ( M1, M2, Ray11(i,j),  RefRay1(i,j), Ray22(i,j), RefRay2(i,j), ePolarRay, rPolarRay);
  pause (0.1)
    end
 end
 

