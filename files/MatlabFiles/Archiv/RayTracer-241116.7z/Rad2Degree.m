function [ a_Degree] =Rad2Degree(a_Rad )
a_Degree = (180*a_Rad)/pi; 
end

